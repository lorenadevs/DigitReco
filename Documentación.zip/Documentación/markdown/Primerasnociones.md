# Primeras nociones

Para entrenar el modelo de Inteligencia Artificial que utilizaremos en DigitReco necesitamos unas cuantas imágenes, pero no 4 ni 400, sino miles.

Para ello haremos uso de un dataset.

Un dataset es un conjunto de datos utilizado en el campo de la inteligencia artificial para entrenar y probar algoritmos de aprendizaje.

Gracias a este dataset podremos crear un algoritmo capaz de aprender patrones y hacer predicciones en base a ello.

Kaggle es una plataforma bien conocida en la comunidad del *Machine Learning* en la cual encontraremos herramientas útiles.

De esta misma página fue de donde obtuve el [dataset de MNIST](<https://www.kaggle.com/datasets/oddrationale/mnist-in-csv/data>) en formato CSV. Este CSV está formado por 60.000 líneas, y cada línea tiene 785 números.

&nbsp;

**¿Por qué 785?**

A un modelo de aprendizaje no podemos enseñarle miles de imágenes y esperar que aprenda de ellas. Nuestro modelo va a necesitar información en bits, por lo que si tomamos como referencia imágenes de 28 píxeles obtendremos 784 valores que corresponden a cada pixel. (28 x 28 = 784).

Cada uno de los 784 números por línea será un número del 0 al 255 haciendo referencia a una escala de grises; siendo 0 negro y 255 blanco.

Mediante estos números estamos haciendo saber al modelo en qué pixeles se encuentran nuestros trazos.

El número extra, el 785, es simplemente el propio número (del 0 al 9) que representa la imagen. De esta manera el modelo tras hacer su predicción verá si el valor real coincide con lo sacado. En base a esto cambiará el algoritmo para aprender de una manera que ofrezca mayor precisión.

&nbsp;

Una alternativa a descargar el dataset en un *CSV* es importarlo desde *Tensorflow*.

***
_Creado con el Personal Edition de HelpNDoc: [Transforma tu documento de Word en un libro electrónico de calidad profesional con HelpNDoc](<https://www.helpndoc.com/es/guias-paso-a-paso/c%C3%B3mo-convertir-un-archivo-docx-de-word-en-un-ebook-epub-o-kindle/>)_
