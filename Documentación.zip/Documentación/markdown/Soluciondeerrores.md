# Solución de errores

**Solución de errores**

Se han observado 4 errores específicos que pueden ocurrir al interactuar con la aplicación.

* **Predicción antes de la finalización de la anterior**: Si se pulsa el botón mientras se está realizando otra predicción se produce una excepción. Esta se ha controlado y nos muestra un mensaje indicando que debemos esperar antes de volver a pulsar el botón.

&nbsp;

![Image](<lib/Nuevo%20tem10.png>)

&nbsp;

* **Pintado fuera del *canvas*:** Si el usuario mantiene el pincel mientras se sale del canvas, aunque esté delimitado por los bordes esto genera una excepción. De ser así, el dibujo no sería válido y se controla de la misma manera.

&nbsp;

![Image](<lib/Nuevo%20tem11.png>)

&nbsp;

* **Fallo en la ejecución:** Si por cualquier motivo la predicción no puede realizarse, no se mostrará ningún número como resultado. El usuario puede solucionar esto instalando las librerías necesarias (las cuales se encuentran en el fichero *requirements.txt*). Instalarlas solo requiere ejecutar el comando *pip install -r requirements.txt* en la terminal. Además, se debe ejecutar con la versión 3.11 de Python. Para ver la versión del sistema podemos ejecutar *python --version*.

&nbsp;

![Image](<lib/Nuevo%20tem12.png>)

&nbsp;

* **No se ha encontrado el directorio *data:*** En él es donde se encuentran tanto el modelo como el script necesario para hacer las predicciones. Esta carpeta viene creada previamente al realizar la descarga del proyecto; prueba a eliminar el existente y descárgalo de nuevo. También puede ocurrir si se ejecuta desde otra ruta la cual no es la esperada; distinta a la ruta desde la que se ejecuta en modo *Debug.* Este error puede ocurrir al ejecutar el programa en *Release*.

&nbsp;

![Image](<lib/Nuevo%20tem13.png>)


***
_Creado con el Personal Edition de HelpNDoc: [Maximiza las capacidades de tu archivo de ayuda CHM con HelpNDoc](<https://www.helpndoc.com/es/descubrir-funciones/crear-archivos-chm-de-ayuda/>)_
