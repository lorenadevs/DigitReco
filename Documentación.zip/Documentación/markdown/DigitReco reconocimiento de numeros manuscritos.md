# DigitReco; reconocimiento de números manuscritos

## Table of contents

- [Introducción](<Introduccion.md>)
  - [Primeras nociones](<Primerasnociones.md>)
- [Información Técnica](<InformacionTecnica.md>)
  - [Generación del modelo](<Generaciondelmodelo.md>)
  - [Cargado del modelo](<Cargadodelmodelo.md>)
  - [Implementación con .NET](<ImplementacionconNET.md>)
  - [De líneas a bytes](<Delineasabytes.md>)
  - [Interfaz gráfica](<Interfazgrafica.md>)
- [Manual de usuario](<Manualdeusuario.md>)
  - [Requisitos previos](<Requisitosprevios.md>)
  - [Interfaz](<Interfaz.md>)
  - [Solución de errores](<Soluciondeerrores.md>)
  - [Más ayuda](<Masayuda.md>)
