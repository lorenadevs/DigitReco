# Interfaz

**Usabilidad**

La interfaz de la aplicación es sencilla; tenemos una UI que nada más abrirla nos invita a deslizar hacia abajo.

&nbsp;

![Image](<lib/Nuevo%20tem6.png>)

&nbsp;

Al deslizar nos encontramos una noción del proceso; de un vistazo se le muestra al usuario que debe dibujar en el lienzo y el programa mostrará el resultado predecido por pantalla.

&nbsp;

![Image](<lib/Nuevo%20tem7.png>)

&nbsp;

Si el usuario sigue desplazando se encuentra el lienzo y el botón de predicción bajo este.&nbsp;

Al presionar el botón aparecerá una animación de carga mientras se esté calculando la predicción. Esta desaparecerá cuando el resultado esté listo.

&nbsp;

![Image](<lib/Nuevo%20tem9.png>)

&nbsp;


***
_Creado con el Personal Edition de HelpNDoc: [Generador de documentación con todas las funciones](<https://www.helpndoc.com/es/>)_
