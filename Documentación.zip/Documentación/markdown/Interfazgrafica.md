# Interfaz gráfica

La interfaz gráfica está formada por un *grid* metido en un *ScrollView*. Este *grid* contiene 2 columnas y 8 filas.

En estas filas están distribuídos componentes como el label que conforma el título, la imagen indicativa del funcionamiento básico, el *canvas,* el botón y el *label* destinado a mostrar la predicción.

&nbsp;

MAUI no tiene de manera nativa un *canvas*, por lo que este ha sido añadido con la *MAUI Community ToolKit.*

Esta puede obtenerse como paquete NuGet, pero deberemos añadirla manualmente en el fichero *MauiProgram.cs*

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; public static MauiApp CreateMauiApp()

&nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; var builder = MauiApp.CreateBuilder();

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; builder

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; .UseMauiApp\<App\>()

**&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; .UseMauiCommunityToolkit()**

&nbsp;

Además añadiremos el espacio de nombres en el fichero *XML* de nuestra interfaz.

&nbsp;

\<ContentPage xmlns="http://schemas.microsoft.com/dotnet/2021/maui"

&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; xmlns:x="http://schemas.microsoft.com/winfx/2009/xaml"

**&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; xmlns:toolkit="clr-namespace:CommunityToolkit.Maui.Views;assembly=CommunityToolkit.Maui"**

&nbsp;

Ya podremos añadir tanto este como cualquier componente del kit de la comunidad de *MAUI*.&nbsp;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \<toolkit:DrawingView

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; LineColor="Black"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; x:Name="drawingCanvas"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; HeightRequest="300"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; WidthRequest="300"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; LineWidth="10"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; BackgroundColor="White"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Grid.Row="6"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Grid.Column="0"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; /\>

&nbsp;

El fondo gradiente se ha conseguido con un *Frame* y creando una brocha con un gradiente lineal de color amarillo desde la posición 0.08 (8%) hasta el color verde en la posición 1 (el 100% del frame).

Este gradiente se aplica como fondo al *Frame*, lo que nos permite conseguir un fondo que cambia gradualmente de amarillo a verde.

&nbsp;

&nbsp; &nbsp; \<Frame BorderColor="White"

&nbsp;&nbsp; &nbsp; &nbsp; HasShadow="True"

&nbsp;&nbsp; &nbsp; &nbsp; CornerRadius="12"\>

&nbsp; &nbsp; &nbsp; &nbsp; \<Frame.Background\>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \<LinearGradientBrush\>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \<GradientStop Color="Yellow"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Offset="0.08" /\>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \<GradientStop Color="Green"

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Offset="1" /\>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \</LinearGradientBrush\>

&nbsp; &nbsp; &nbsp; &nbsp; \</Frame.Background\>

&nbsp;

Se han utilizado 2 fuentes personalizadas almacenadas en la carpeta *Fonts* y añadidas en el *MauiProgram.cs*.

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; fonts.AddFont("LTSaeada-Light.otf", "Saeada");

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; fonts.AddFont("GalleroVintage-DemoVersion-Regular.otf", "GalleroVintage");


***
_Creado con el Personal Edition de HelpNDoc: [Facilita la documentación con la interfaz de usuario limpia y eficiente de HelpNDoc](<https://www.helpndoc.com/es/descubrir-funciones/asombrosa-interfaz-de-usuario/>)_
