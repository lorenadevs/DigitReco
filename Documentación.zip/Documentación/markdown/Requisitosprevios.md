# Requisitos previos

Para que el programa funcione de manera óptima necesita las **librerías** indicadas en el *requirements.txt.*

Estas son la versión 2.12 de ***Tensorflow*** y la 1.23.5 de ***Numpy***.

Podemos realizar la instalación de ellas con ***pip install -r requirements.txt**.*

&nbsp;

Además, la **versión de Python debe ser la 3.11**. Esta puede instalarse desde la [web oficial.](<https://www.python.org/downloads/release/python-3116/>)

Es importante que durante la instalación marquemos la opción de añadir Python al Path. En caso de no tener Python en el Path, deberá modificarse el código con la ruta de instalación del propio Python.

&nbsp;

Actual:

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.FileName = "python3.11.exe"; // Comando para ejecutar Python

&nbsp;

Cambio si no está en el path:

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.FileName = @"C:\\Users\\loren\\AppData\\Local\\Microsoft\\WindowsApps\\python3.11.exe"; // Comando para ejecutar Python


***
_Creado con el Personal Edition de HelpNDoc: [Por qué Microsoft Word no está recortado para la documentación: los beneficios de una herramienta de creación de ayuda](<https://www.helpndoc.com/es/noticias-y-articulos/2022-09-27-por-qu%C3%A9-utilizar-una-herramienta-de-creaci%C3%B3n-de-documentaci%C3%B3n-de-ayuda-en-vvezz-de-microsoft-word-para-producir-documentaci%C3%B3n-de-alta-calidad/>)_
