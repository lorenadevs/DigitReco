# Generación del modelo

El modelo a entrenar está programado en Python.

Como alternativa a cargar el CSV local podemos utilizar la librería de datasets de Tensorflow para cargar el MNIST únicamente con 1 línea de código:

&nbsp;

&nbsp;

*import* tensorflow\_datasets *as* tfds

&nbsp;

dataset, metadata = tfds.*load*('mnist', *as\_supervised*=*True*, *with\_info*=*True*)

&nbsp;

&nbsp;

La función *load()* de Tensorflow devuelve 2 valores; el propio dataset y metadata (lo cual nos puede ser útil para obtener información extra del conjunto de datos).

&nbsp;

Una vez almacenado el dataset en la variable *dataset*, vamos a dividir el set en 2.

Una parte será el conjunto de entreno y otro el de pruebas. Esto se hace porque si utilizásemos los mismos datos de entreno para hacer las pruebas los resultados del modelo final podrían ser más imprecisos.

&nbsp;

&nbsp;

train\_dataset, test\_dataset = dataset\['train'\], dataset\['test'\]

&nbsp;

&nbsp;

Podemos obtener el tamaño del ambos conjuntos con los metadatos. Esta información la utilizaremos más adelante.

&nbsp;

&nbsp;

num\_train\_examples = metadata.splits\['train'\].num\_examples

num\_test\_examples = metadata.splits\['test'\].num\_examples

&nbsp;

&nbsp;

Una vez divididos los datos necesitamos normalizarlos.

Recordemos que los valores que se encuentran en el dataset son números del 0 al 255, pero para que nuestro programa Python lo entienda queremos pasarle o 0 o 1.

Creamos una función encargada de normalizar estos datos casteando los datos (para poder operar con ellos) y posteriormente dividiéndolos entre 255.&nbsp;

Los datos normalizados serán 0 cuando ese pixel específico sea negro y 1 cuando blanco.

&nbsp;

&nbsp;

def *normalize*(*images*, *labels*):

    images = tf.*cast*(*images*, *tf*.*float32*)

    images /= 255

    return images, labels

\
&nbsp;

train\_dataset = train\_dataset.*map*(*normalize*)

test\_dataset = test\_dataset.*map*(*normalize*)

&nbsp;

&nbsp;

**Arquitecturas de redes neuronales**

En este programa el modelo está creado con una red neuronal recurrente (RNN).

Las redes neuronales recurrentes se conforman por la capa inicial, la final y las ocultas. Las capas ocultas son todas aquellas intermedias entre la inicial y la final.

En estas capas ocultas obtenemos como entrada la salida de la capa anterior. Además, tienen una copia en memoria que permite cambiar la predicción en base a esta.

&nbsp;

Por ejemplo, si detectar el número 5 fuese detectar la secuencia 101, la capa oculta recibirá como entrada el 1 y lo guardará en memoria. Posteriormente cuando reciba los siguientes números podrá ajustar la predicción al conjunto total. El modelo no sabrá qué número es aquel que comienza por 1, pero sí podrá intentar predecir cuál es aquel que empieza por 1 y le siguen X números.

&nbsp;

**Implementación de la RNN**

Para crear una RNN e indicar las capas que la componen lo hacemos indicando las capas que la componen. Observamos que en este caso son 4.

&nbsp;

La primera capa es ***Flatten*** porque así nos permite convertir los datos de entrada en un formato unidimensional de 28x28 compatible con los datos del dataset. El número final indica los canales de colores. Si la imagen tuviese color querríamos que este número fuese el 3 (R,G, B) pero en este caso solo necesitamos 1 al tener las imágenes en escala de grises.

&nbsp;

El resto de capas son **densas** (*Dense*) lo cual indica que todas las neuronas de la capa están conectadas con todas las de la capa anterior.

Como primer parámetro se indica el **número de neuronas** de esa capa; nos encontramos con 64 y con 10.

Este número podemos variarlo en base a nuestras necesidades, pero para un conjunto de datos de este tamaño 64 neuronas son suficientes.

Cuantas más neuronas asignemos a las capas mayor será el uso de recursos y el tiempo de entrenamiento del modelo.

&nbsp;

La **capa final** tiene 10 neuronas, 1 por cada predicción posible (del 0 al 9).

&nbsp;

&nbsp;

model = tf.keras.*Sequential*(\[

    *tf*.*keras*.*layers*.*Flatten*(*input\_shape*=(28,28,1)), *# 28 x 28 píxeles cada imagen*

    *tf*.*keras*.*layers*.*Dense*(64, *activation*=*tf*.*nn*.*relu*), *#Capa oculta 1*

    *tf*.*keras*.*layers*.*Dense*(64, *activation*=*tf*.*nn*.*relu*), *#Capa oculta 2*

    *tf*.*keras*.*layers*.*Dense*(10, *activation*=*tf*.*nn*.*softmax*)

\])

&nbsp;

&nbsp;

**Funciones del modelo**

Con el método *compile()* estamos configurando el modelo para que pueda ver de mejor manera los patrones en los datos pasados.

&nbsp;

*Adam* es el algoritmo de optimización que se utilizará durante el entrenamiento. Tenemos mucho donde elegir; este específico permite modificar la tasa de aprendizaje conforme cambian las condiciones.

&nbsp;

Como función de pérdida (*loss*) tenemos asignada *sparse\_categorical\_crossentropy* porque es la adecuada para entradas de números enteros.

&nbsp;

Como métrica a obtener establecemos la proporción de predicciones correctas realizadas en relación con el número total de predicciones; la *accuracy.*

&nbsp;

&nbsp;

model.*compile*(

    *optimizer*='adam',

    *loss*='sparse\_categorical\_crossentropy',

    *metrics*=\['accuracy'\]

)

&nbsp;

&nbsp;

**Preparación del dataset**

Agrupamos los datos en grupos de 64 para entrenar al modelo de manera eficiente y los aleatorizamos y repetimos infinitamente.

Más tarde veremos durante cuánto tiempo (cuántas *epochs; épocas*) entrenamos al modelo, pero dentro de este entreno jamás nos quedaremos sin datos (gracias al *repeat()*), por más largo que sea el tiempo de entreno.

&nbsp;

&nbsp;

BATCHSIZE = 64

train\_dataset = train\_dataset.*repeat*().*shuffle*(*num\_train\_examples*).*batch*(*BATCHSIZE*) *#Aleatorizar los datos*

test\_dataset = test\_dataset.*batch*(*BATCHSIZE*)

&nbsp;

&nbsp;

**Entreno del modelo**

Al comenzar a entrenar un modelo este tiene valores aleatorios en cada conexión entre neuronas. El hecho de comparar las salidas del programa con los resultados correctos permite mejorar el algoritmo sucesivamente mientras el modelo ajusta distintos pesos.

Como parámetros al método *fit()* indicamos el dataset con los datos de entreno, las épocas y los pasos por época.

&nbsp;

En cada época (*epoch*) se entrena el conjunto de datos completo; por lo que en 50 épocas se entrena 50 veces toooodo el set.

&nbsp;

Los *steps per epoch* son la cantidad de veces que el modelo actualizará sus pesos durante cada época.

DIvidiendo el tamaño del set entre el *batchsize* obtenemos el número necesario para cubrir todos los ejemplos.

&nbsp;

model.*fit*(

    *train\_dataset*, *epochs*=50,

    *steps\_per\_epoch*=*math*.*ceil*(*num\_train\_examples*/*BATCHSIZE*)

)

&nbsp;

&nbsp;

**Guardado del modelo**

Por último, el modelo es guardado en la ruta en la que se encuentra el script. Para el funcionamiento de la aplicación este modelo ya estará en la propia carpeta del proyecto de Visual Studio.

El modelo puede guardarse tanto en formato *h5* como *keras*.

&nbsp;

&nbsp;

model.*save*('C:/Users/loren/Downloads/dataset/modelo.h5')

&nbsp;

&nbsp;


***
_Creado con el Personal Edition de HelpNDoc: [Haz que la revisión de la documentación sea muy sencilla con el analizador de proyectos avanzado de HelpNDoc](<https://www.helpndoc.com/es/descubrir-funciones/analizador-avanzado-proyectos/>)_
