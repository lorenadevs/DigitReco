# Cargado del modelo

Una vez obtenido el archivo *h5* con el modelo entrenado, se crea otro script Python encargado de llamar a este modelo.

&nbsp;

Tras muchas pruebas he visto que lo que mejor ha funcionado es pasarle la lista de bytes por argumentos al script. Esta lista será el que representa el color de cada pixel del dibujo del usuario.

&nbsp;

Una vez obtenida la lista se convierte en una pero con un formato específico de *Numpy* (una librería de Python) para trabajar con esta.

Le hacemos un *reshape* a la lista para asegurarnos que tiene el formato requerido por nuestro modelo, siendo 1 el número de imágenes a predecir de manera simultánea, 28 los píxeles de alto, 28 los de ancho y el argumento final indica de nuevo el canal de color (gris).

&nbsp;

&nbsp;

def *predecir\_exc*(*arr*):

    try:

        modelo = tf.keras.models.*load\_model*("ruta/modelo.h5")

&nbsp;

        arr = np.*array*(*arr*)

        arr = arr.*reshape*(1, 28, 28, 1)

´

&nbsp;

**Realizar la predicción**

Llamamos a la función *predict()* del modelo previamente cargado. Le pasaremos como argumento la lista pasada por parámetros y con formato *Numpy* y el número de imágenes a predecir.

&nbsp;

&nbsp;

        prediction\_values = modelo.*predict*(*arr*, *batch\_size* = 1)

&nbsp;

&nbsp;

**Devolución de datos**

En *prediction\_values* se encuentran todos los números junto a su porcentaje de *accuracy*. Es por esto que si queremos sacar el número que es más probable de ser el dibujado por el usuario queremos sacar el máximo. Esto lo conseguimos con la función *argmax()* de *Numpy.*

&nbsp;

       &nbsp;

prediction = *str*(*np*.*argmax*(*prediction\_values*)) *#Extrae la que mayor certeza tiene*

&nbsp;

        *print*("Predicción final:", *prediction*)

&nbsp;

&nbsp;

El hecho de imprimirlo por pantalla nos será útil para más tarde implementarlo en .NET.

&nbsp;

**Ejecución del programa**

En el main nos encontramos una variable que almacena la lista introducida por argumentos.

Para que la aplicación funcionase mucho más rápido la lista está serializada en JSON (más adelante veremos cómo), porque pasar cada número como argumento independiente (784 argumentos) no era nada óptimo y costaba mucho rendimiento.

&nbsp;

Es por ello que lo deserializamos importando la librería *json* y llamando a su función *loads()*

&nbsp;

&nbsp;

def *main*():

    serialized\_array = sys.argv\[1\]

&nbsp;

    *# Deserializar el array desde JSON*

    arr = json.*loads*(*serialized\_array*)

   &nbsp;

    *# Llamar a la función de predicción con el array deserializado*

    *predecir\_exc*(*arr*)

&nbsp;


***
_Creado con el Personal Edition de HelpNDoc: [Actualice su proceso de documentación con una herramienta de creación de ayuda](<https://www.helpndoc.com/es/noticias-y-articulos/2022-09-27-por-qu%C3%A9-utilizar-una-herramienta-de-creaci%C3%B3n-de-documentaci%C3%B3n-de-ayuda-en-vvezz-de-microsoft-word-para-producir-documentaci%C3%B3n-de-alta-calidad/>)_
