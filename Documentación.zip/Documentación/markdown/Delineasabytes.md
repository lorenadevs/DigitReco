# De líneas a bytes

Ya tenemos la implementación para poder pasarle la lista al script pero, ¿cómo obtenemos esta lista de números?

Recordemos que en la lista deben encontrarse 784 números con valor o 0 o 1.

&nbsp;

Para ello en la función llamada al hacer clic sobre el botón *Predict* obtenemos el flujo dibujado por el usuario, lo cargamos a un flujo de memoria y este flujo lo pasamos a una imagen.

&nbsp;

&nbsp; &nbsp; private async void OnPredictClicked(object sender, EventArgs e)

&nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; try

&nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; int pixelesRequeridos = 28;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using var stream = await drawingCanvas.GetImageStream(pixelesRequeridos, pixelesRequeridos);

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using var memoryStream = new MemoryStream();

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; stream.CopyTo(memoryStream);

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; stream.Position = 0;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; memoryStream.Position = 0;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; await System.IO.File.WriteAllBytesAsync(@"C:\\Users\\loren\\Downloads\\imagen.png", memoryStream.ToArray());

&nbsp;

Sin embargo esta imagen es guardada a partir del trazo del propio usuario; no respeta los márgenes. Esto suponía un problema ya que las imágenes con las que ha sido entrenado el modelo son imágenes con márgenes en todos los lados.

&nbsp;

![Image](<lib/Nuevo%20tem4.png>)

&nbsp;

Es por este motivo que necesitamos añadir manualmente los márgenes.

Para ello creamos una nueva imagen haciendo uso de la clase *Bitmap* con la misma anchura y altura que la original pero con 200 píxeles más. Estos píxeles podemos adaptarlos a cada caso, pero con 200 he obtenido buenos resultados ya que tomamos como imagen original la del canvas con tamaño 300 x 300; antes de redimensionarlas a 28 x 28.

&nbsp;

Con la clase *Graphics* podemos centrar la imagen original en la nueva y guardarla en memoria para utilizarla a la hora de pasar la imagen a bytes.

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using var originalImage = System.Drawing.Image.FromStream(memoryStream);

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; int newWidth = originalImage.Width + 200; // 200 píxeles de padding a cada lado

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; int newHeight = originalImage.Height + 200; // 200 píxeles de padding arriba y abajo

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using var paddedImage = new Bitmap(newWidth, newHeight);

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // Dibujar la imagen original en la nueva imagen centrada dentro del padding

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using (Graphics g = Graphics.FromImage(paddedImage))

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; g.Clear(System.Drawing.Color.LightGray); // Color del padding mismo que la imagen original

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; int x = (newWidth - originalImage.Width) / 2;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; int y = (newHeight - originalImage.Height) / 2;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; g.DrawImage(originalImage, x, y);

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; paddedImage.Save(@"ruta\\imagen\_con\_padding.png", System.Drawing.Imaging.ImageFormat.Png);

&nbsp;

&nbsp;

Además, de esta manera no nos influye tanto en la predicción la posición en la que el usuario dibuje el número, ya que sea como sea la imagen original siempre será colocada en el centro y sus márgenes extras añadidos.

Aún así la posición y tamaño siguen siendo factores a tener en cuenta, ya que si el número es tan pequeño cuando reescalemos la imagen a 28 x 28 píxeles el modelo perderá mucha precisión.

&nbsp;

![Image](<lib/Nuevo%20tem5.png>)

&nbsp;

&nbsp;

No llegaba a entender los valores que se imprimían al intentar convertir los píxeles individuales de la imagen a números; el valor 211 se repetía mucho cuando debía ser el 255 (el blanco).

Al abrir la imagen reescalada a 28 píxeles con Photoshop me di cuenta de que (aunque es algo que se ve a simple vista no me había percatado) por algún motivo al obtener la imagen de lo dibujado con *GetImageStream(),* ¡el fondo siempre es gris\! No es blanco como en el canvas.

Por lo tanto, el 211 es el gris del fondo.

Haciendo una leve modificación en el código haremos que los píxeles a tomar en cuenta como pintados sean los que tengan valor inferior a 200.

&nbsp;

![Image](<lib/lvS9dcd19G.png>)

&nbsp;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using (var fileStream = new FileStream(@"ruta\\imagen\_con\_padding.png", FileMode.Open))

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using (var ms = new MemoryStream())

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; await fileStream.CopyToAsync(ms);

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; fileStream.Position = 0;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ms.Position = 0;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; byte\[\] pixeles = Convert(ms);

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; //ShowArray(pixeles);

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for (int i = 0; i \< pixeles.Length; i++)

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; **if (pixeles\[i\] \< 200) //\<200 son los de color negro, el resto forman parte del fondo gris**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; pixeles\[i\] = 1;**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; pixeles\[i\] = 0;**

**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }**

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }

&nbsp;

Una vez normalizado el array de píxeles (pasados los valores a 0 o 1), lo convertimos en un array de *float* para no tener problemas de compatibilidad al pasarlo como argumento al script.

Lo pasamos en la función *ExecuteScript(),* la cual es la que anteriormente comentábamos que ejecutaba por debajo una terminal#8202;*.*

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; float\[\] floats = new float\[pixeles.Length\];

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for (int i = 0; i \< pixeles.Length; i++)

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; floats\[i\] = pixeles\[i\];

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; await ExecuteScript(floats);

&nbsp;

Lo mostramos en la interfaz estableciendo el *Text* del label con el texto pasado por su expresión regular correspondiente.

Al mismo tiempo desactivamos el indicador de carga.

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; lblPrediction.Text = reemplazar;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; loadingIndicator.IsRunning = false;

***
_Creado con el Personal Edition de HelpNDoc: [Experimenta el poder y la simplicidad de la interfaz de usuario de HelpNDoc](<https://www.helpndoc.com/es/descubrir-funciones/asombrosa-interfaz-de-usuario/>)_
