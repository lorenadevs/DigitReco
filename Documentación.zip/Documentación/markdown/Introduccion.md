# Introducción

DigitReco es un programa encargado de reconocer dígitos escritos por el usuario y realizar una predicción en base a los píxeles que conforman el dígito.

&nbsp;

**Origen de la idea**

Esta idea de proyecto surgió como un *sideproject* que quería realizar a mitad de curso.

No suelo dedicarle mucho tiempo a los videojuegos, por lo que cuando lo hago busco una experiencia que no requiera más trasfondo que saber a lo que estás jugando en el momento. No me gusta la necesidad de tener que *pillar* la mecánica conforme inviertes horas o el tener que recordar la historia de un videojuego que probablemente lleve meses sin jugar.

Es por este motivo que disfruto mucho las demos; tienen una duración perfecta y te aportan todo lo necesario para disfrutar el videojuego en el momento.

Una de las demos que probé fue *Dr Kawashima's Brain Training;* qué nostalgia.

El *Brain Training* es uno de esos juegos que aunque no se le echaba muchas horas todos lo teníamos en la DS hace años. ¡Pues parece ser que había una demo para la Switch\!

Me decidí a probarla y me pareció maravillosa; consiguen mantener un formato que cualquiera puede entender, con mucha simpleza pero a la vez ofreciendo una experiencia de usuario buenísima.&nbsp;

La idea de aplicación no parece muy compleja; distintas actividades para entrenar tu lógica y memorización y un *trackeo* diario de ella para ver cómo vas mejorando. Siendo una idea como esta seguro que tenían que haber muchas alternativas para Android, ¿verdad?

A la conclusión que llegué tras probar un par de ellas es que cumplen su función pero no logran esa inmersión que Nintendo sí; en Android al fin y al cabo obtenías los resultados de cada actividad pero no era la misma sensación simplemente por cómo se presentaba al usuario.

Nintendo a pesar de mantenerse simple en interfaz proporcionaba una inmersión muy buena.

&nbsp;

![Kawashima's Brain Training (Brain Age) Announced For Switch, 44% OFF](<lib/Nuevo%20tem.jpg>)

&nbsp;

&nbsp;

Específicamente me gustó el de cálculo de números, por lo que pensé en centrarme en este aspecto más que en una aplicación completa con distintos ejercicios de lógica.

Quería desarrollar yo misma una aplicación con esa UX que buscaba en otras, pero, ¿cómo puede mi programa entender que las 2 rayas que ha dibujado el usuario son el número 9?


***
_Creado con el Personal Edition de HelpNDoc: [Agilice su proceso de documentación con la plantilla HTML5 de HelpNDoc](<https://www.helpndoc.com/es/descubrir-funciones/producir-paginas-web-html/>)_
