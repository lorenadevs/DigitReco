# Implementación con .NET

El *frontend* de esta aplicación está realizado utilizando tecnología *.NET;* específicamente *MAUI*.

MAUI *(Multi-Platfrom App UI)* es una tecnología que ofrece la gran ventaja de ser multiplataforma, permitiéndonos así correr las aplicaciones en Windows, Mac, Android e iOS.

Debido a problemas con la implementación del script en Python este programa **corre únicamente en Windows** (si miramos el código tendremos varios warnings del estilo *Esto podría no funcionar en X plataforma*)**.**

### Implementación de Python en C#

Pero si el script que se encarga de realizar predicciones está desarrollado en Python, ¿cómo podemos desde Visual Studio llamar a este?

Hay paquetes de Visual Studio que podemos instalar fácilmente los cuales nos prometen compatibilidad con Python. Razón no les falta, con muy pocas líneas de código puedes integrar fácilmente tu script desarrollado en Python, pero el problema viene cuando necesitamos cargar librerías externas. Es decir, cuando tenemos varios *import* en el script. En este caso tenemos el de *Tensorflow, Numpy* y *JSON.*

&nbsp;

**Herramientas de implementación**

*IronPython* y *Pythonnet* son herramientas muy utilizadas pero con gran cantidad de problemas al tratar de implementarlas en MAUI. Codificaciones incorrectas, escasez de permisos para acceder a ciertos archivos y problemas de memoria son algunos de los problemas que me encontré con ellas.

Curiosamente la solución de muchos de estos problemas estaba en cambiar la plataforma del proyecto y no dejar la predeterminada *Any CPU*, pero al estar realizando la aplicación con tecnología *MAUI* este cambio de plataforma no tenía sentido y daba problema por todos lados.

&nbsp;

¿Entonces?

&nbsp;

**Alternativas**

La alternativa a tantos problemas de compatibilidad era directamente ejecutar una terminal por debajo pero sin mostrársela al usuario.

Esto podemos lograrlo así:

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; string pythonScript = @"ruta\\cargarModelo.py";

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ProcessStartInfo start = new ProcessStartInfo();

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.FileName = @"ruta\\python3.11.exe"; // Comando para ejecutar Python&nbsp;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.Arguments = $"{pythonScript} {serializedArray}"; // Pasar el array serializado como argumento al script Python

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.UseShellExecute = false; // No usar shell para la ejecución

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.RedirectStandardOutput = true; // Redireccionar salida estándar

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; start.CreateNoWindow = true; // No crear ventana

&nbsp;

**Captura de la salida y mostrado en la interfaz**

Si capturamos la salida del programa con *ReadToEnd()*, se almacenará todo lo mostrado por pantalla por el script de Python. Es por esto que anteriormente comentamos que el *print* con la predicción final nos sería de ayuda.

&nbsp;

Crearemos una expresión regular para únicamente mostrar en nuestra UI el número con mayor predicción. En Python lo mostrábamos por pantalla como *Predicción final: N*, por lo que la expresión regular filtrará por un número tras 2 puntos (: \[0-9\]).

Obtenemos el número y con un *replace()* reemplazamos estos 2 puntos por un espacio vacío.

Ahora nuestra variable *reemplazar* contiene únicamente el número con mayor *accuracy*.

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // Inicia el proceso

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; using (Process process = Process.Start(start))

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // Leer la salida estándar del proceso Python

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; string output = process.StandardOutput.ReadToEnd();

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; //reemplazar = output;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // Esperar a que el proceso Python termine

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; process.WaitForExit();

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // Mostrar la salida del script Python

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; string pattern = @": \[0-9\]";

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; //string patternOthers = @"(?\<=STARTHERE.\*?)aa(?=.\*?ENDHERE)";

&nbsp;

&nbsp;

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; MatchCollection matches = Regex.Matches(output, pattern);

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; reemplazar = matches\[1\].Value.Replace(":", "").ToString();

&nbsp;

Todo este proceso requiere que el script se ejecute con el tiempo que ello conlleva. Para evitar que el programa se congele mientras se calcula la predicción (sobre unos 3 segundos), encapsulamos esto en una función y esta en un hilo.

Al llamar a esta función (que la llamaremos al accionar el botón de predicción) se muestra un indicador de carga (*ActivityIndicator*), y al obtener el resultado final del script este se vuelve a detener, haciéndole saber así al usuario que la predicción ha terminado.

&nbsp;

![Image](<lib/Nuevo%20tem2.png>)&nbsp; &nbsp; ![Image](<lib/Nuevo%20tem3.png>)

***
_Creado con el Personal Edition de HelpNDoc: [Convertir documentos de Word en libros electrónicos: una guía paso a paso con HelpNDoc](<https://www.helpndoc.com/es/guias-paso-a-paso/c%C3%B3mo-convertir-un-archivo-docx-de-word-en-un-ebook-epub-o-kindle/>)_
