# Más ayuda

Si han surgido problemas no contemplados en este manual puedes contactarme en el correo [*lorenasanchezdev@gmail.com* ](<mailto:lorenasanchezdev@gmail.com?subject=Ayuda>)*o en [Github*](<https://github.com/kxtxrinx>)*.*

***
_Creado con el Personal Edition de HelpNDoc: [Creación de ayuda CHM, PDF, DOC y HTML desde un solo lugar](<https://www.helpndoc.com/es/herramienta-creacion-documentacion-ayuda/>)_
